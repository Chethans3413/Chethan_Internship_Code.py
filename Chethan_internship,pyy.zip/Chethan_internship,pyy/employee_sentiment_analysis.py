import pandas as pd
import numpy as np
from datetime import datetime
from transformers import pipeline
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import seaborn as sns
import os

df = pd.read_csv("C:\Users\cheth\Downloads\test(in).csv")
df['Timestamp'] = pd.to_datetime(df['Timestamp'])
df['Month'] = df['Timestamp'].dt.to_period('M')
# --- Suppress warnings for cleaner output ---
warnings.filterwarnings('ignore')

# --- Sample Data mimicking test.csv structure ---
data = {
    'Employee_ID': ['E001', 'E002', 'E001', 'E003', 'E002', 'E001', 'E004', 'E003', 'E001', 'E002', 'E005', 'E001', 'E003', 'E003', 'E004', 'E005', 'E001', 'E002', 'E003', 'E003'],
    'Message': [
        "I love this new project assignment, great team!",
        "The server crashed again, I'm very frustrated with the tools.",
        "Quick update: finished the report as requested.",
        "Feeling great about the quarterly results.",
        "My workload is overwhelming, can someone help?",
        "Neutral comment on the meeting agenda.",
        "This bug fix is impossible, huge setback.",
        "Positive feedback on the new coffee machine!",
        "The deadline is impossible to meet, this is stressful.",
        "All systems operational, no issues.",
        "I hate the new policy, completely unfair.",
        "Another great day closing tickets.",
        "My last three requests were ignored. Not happy.",
        "The team lead is being extremely supportive.",
        "Final negative message for the month, I quit.",
        "Happy to help on the next sprint.",
        "I'm ready for the new challenge next month.",
        "This needs improvement. It is a disaster.",
        "A truly negative experience this week.",
        "Very frustrated with the lack of clarity on the next steps."
    ],
    'Timestamp': [
        '2025-01-05 09:00:00', '2025-01-08 11:30:00', '2025-01-15 14:00:00',
        '2025-01-20 16:00:00', '2025-01-22 10:00:00', '2025-01-25 12:00:00',
        '2025-01-28 15:00:00', '2025-02-01 09:00:00', '2025-02-03 11:00:00',
        '2025-02-05 13:00:00', '2025-02-08 15:00:00', '2025-02-10 10:00:00',
        '2025-02-15 14:00:00', '2025-02-18 16:00:00', '2025-02-25 10:00:00',
        '2025-03-01 11:00:00', '2025-03-05 12:00:00', '2025-03-10 14:00:00',
        '2025-03-15 16:00:00', '2025-03-20 09:00:00'
    ]
}
df = pd.DataFrame(data)
df['Timestamp'] = pd.to_datetime(df['Timestamp'])
df['Month'] = df['Timestamp'].dt.to_period('M')

# --- Global Score Mapping ---
SCORE_MAPPING = {'Positive': 1, 'Negative': -1, 'Neutral': 0}

print(f"--- Starting Employee Sentiment Analysis Project ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')}) ---")
print(f"Total initial records: {len(df)}")


## Task 1: Sentiment Labeling

# Initialize a pre-trained sentiment analysis pipeline
# (A fast, small Transformer model suitable for quick inference)
try:
    sentiment_pipeline = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english")
except Exception as e:
    print(f"Warning: Could not load Hugging Face model. Falling back to VADER. Error: {e}")
    # Fallback to VADER if transformer model fails to load
    sentiment_pipeline = None
    import nltk
    nltk.download('vader_lexicon', quiet=True)


def label_sentiment(message, pipeline_model):
    """Labels sentiment using a Transformer model or VADER fallback."""
    if pipeline_model:
        try:
            result = pipeline_model(message, truncation=True)[0]
            label = result['label']
            if label == 'POSITIVE':
                return 'Positive'
            elif label == 'NEGATIVE':
                return 'Negative'
        except Exception:
            # Fall through to VADER for true neutral/error cases
            pass

    # VADER Lexicon Fallback/Check
    analyzer = SentimentIntensityAnalyzer()
    score = analyzer.polarity_scores(message)['compound']
    if score >= 0.05:
        return 'Positive'
    elif score <= -0.05:
        return 'Negative'
    else:
        return 'Neutral'

# Augment the dataset with the new sentiment column
df['Sentiment'] = df['Message'].apply(lambda x: label_sentiment(x, sentiment_pipeline))
df['Sentiment_Value'] = df['Sentiment'].map(SCORE_MAPPING)

print("\n[TASK 1 COMPLETE] Sentiment Labeling Added.")


## Task 2: Exploratory Data Analysis (EDA)

# 1. Overall Data Structure
print("\n--- EDA: Data Structure and Distribution ---")
print(f"Total Records: {len(df)}")
print(f"Unique Employees: {df['Employee_ID'].nunique()}")

# 2. Sentiment Distribution
sentiment_counts = df['Sentiment'].value_counts(normalize=True).mul(100).round(1)
print("\nSentiment Distribution (Percentage):")
print(sentiment_counts)

# 3. Visualization: Sentiment Distribution
plt.figure(figsize=(8, 5))
sns.barplot(x=sentiment_counts.index, y=sentiment_counts.values, palette="viridis")
plt.title('Distribution of Employee Message Sentiment')
plt.ylabel('Percentage (%)')
plt.xlabel('Sentiment')
plt.savefig('chart_sentiment_distribution.png')
# plt.show() # Disabled for headless execution

# 4. Visualization: Trends Over Time
monthly_sentiment = df.groupby('Month')['Sentiment_Value'].mean().reset_index()

plt.figure(figsize=(10, 6))
sns.lineplot(x=monthly_sentiment['Month'].astype(str), y='Sentiment_Value', data=monthly_sentiment, marker='o')
plt.title('Average Employee Sentiment Over Time')
plt.ylabel('Average Sentiment Score (1=Pos, -1=Neg)')
plt.xlabel('Month')
plt.xticks(rotation=45)
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.savefig('chart_monthly_trend.png')
# plt.show() # Disabled for headless execution

print("[TASK 2 COMPLETE] EDA and Charts Saved.")


## Task 3: Employee Score Calculation

# Group by Month and Employee_ID and calculate the sum of sentiment values
monthly_scores = df.groupby(['Month', 'Employee_ID'])['Sentiment_Value'].sum().reset_index(name='Monthly_Score')

print("\n[TASK 3 COMPLETE] Monthly Scores Calculated.")


## Task 4: Employee Ranking

def get_top_ranked(group, score_type='Positive', n=3):
    """Ranks employees based on score, using Employee_ID for secondary sort."""
    if score_type == 'Positive':
        # Sort by score descending, then by Employee_ID ascending (alphabetical)
        ranked = group.sort_values(by=['Monthly_Score', 'Employee_ID'], ascending=[False, True])
    else: # Negative (lowest score is most negative)
        # Sort by score ascending, then by Employee_ID ascending
        ranked = group.sort_values(by=['Monthly_Score', 'Employee_ID'], ascending=[True, True])
    return ranked.head(n)

# Apply the ranking function to each month group
top_positive = monthly_scores.groupby('Month').apply(lambda x: get_top_ranked(x, 'Positive', 3)).reset_index(drop=True)
top_negative = monthly_scores.groupby('Month').apply(lambda x: get_top_ranked(x, 'Negative', 3)).reset_index(drop=True)

print("\n[TASK 4 COMPLETE] Employee Rankings Generated.")
print("\n--- TOP POSITIVE EMPLOYEES ---")
print(top_positive[['Month', 'Employee_ID', 'Monthly_Score']])
print("\n--- TOP NEGATIVE EMPLOYEES ---")
print(top_negative[['Month', 'Employee_ID', 'Monthly_Score']])


## Task 5: Flight Risk Identification

# 1. Count negative messages per employee per month
negative_counts = df[df['Sentiment'] == 'Negative'].groupby(['Month', 'Employee_ID']).size().reset_index(name='Negative_Count')

# 2. Identify flight risks (4 or more negative messages)
FLIGHT_RISK_THRESHOLD = 4
flight_risks = negative_counts[negative_counts['Negative_Count'] >= FLIGHT_RISK_THRESHOLD]

print("\n[TASK 5 COMPLETE] Flight Risk Assessment.")
print(f"\n--- FLIGHT RISKS (Threshold: >= {FLIGHT_RISK_THRESHOLD} Negative Msgs) ---")
if flight_risks.empty:
    print("NO FLIGHT RISKS IDENTIFIED.")
else:
    print(flight_risks)


## Task 6: Predictive Modeling (Linear Regression)

# 1. Data Preparation
# Count total messages per employee per month
monthly_counts = df.groupby(['Month', 'Employee_ID']).size().reset_index(name='Total_Messages')

# Merge scores and counts to get the regression dataset
regression_df = pd.merge(monthly_scores, monthly_counts, on=['Month', 'Employee_ID'])

# Define X (independent: message volume) and Y (dependent: monthly score)
X = regression_df[['Total_Messages']]
Y = regression_df['Monthly_Score']

# 2. Model Development
model = LinearRegression()
model.fit(X, Y)

# 3. Visualization: Regression Plot
plt.figure(figsize=(10, 6))
sns.regplot(x='Total_Messages', y='Monthly_Score', data=regression_df, scatter_kws={'alpha':0.6}, line_kws={'color':'red'})
plt.title('Linear Regression: Message Volume vs. Sentiment Score')
plt.xlabel('Total Messages Sent per Month')
plt.ylabel('Monthly Sentiment Score')
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.savefig('chart_linear_regression.png')
# plt.show() # Disabled for headless execution

print("\n[TASK 6 COMPLETE] Linear Regression Model Developed and Chart Saved.")
print(f"Model Coefficient (Volume effect on Score): {model.coef_[0]:.4f}")
print("--- PROJECT COMPLETE ---")

# --- Export final augmented data for reference ---
df.to_csv('test_labeled_output.csv', index=False)
print("Augmented data saved to: test_labeled_output.csv")